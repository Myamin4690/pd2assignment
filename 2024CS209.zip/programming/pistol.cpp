#include<iostream>
using namespace std;
main()
{
cout<<"        +--^---------- , -------- , ----- , --------^-,         "<<endl;
cout<<"         | |||||||||    ,----------,       |           O        "<<endl;
cout<<"         ,+--------------------------------^-----------|        "<<endl;
cout<<"           ',---------,---------,--------------------'          "<<endl;
cout<<"              / xxxxxx /,|       /,                             "<<endl;
cout<<"             / xxxxxx /  |      /,                              "<<endl;
cout<<"            / xxxxxx /,-------,                                 "<<endl;
cout<<"           / xxxxxx /                                           "<<endl;
cout<<"          / xxxxxx /                                            "<<endl;
cout<<"         (--------(                                             "<<endl;
cout<<"          ,------,                                              "<<endl;
}
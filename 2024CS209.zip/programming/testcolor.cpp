#include<iostream>
using namespace std;
main()
{
system("color 46");
cout<<"this is my color text";


}